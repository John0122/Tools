Target Web public download sample.
No user data is stored.
